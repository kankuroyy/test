// QRコード作成
var FILE_LIST_TXT = "list.txt";
// 利用するライブラリ
var BarcodeFormat = Packages.com.google.zxing.BarcodeFormat;
var Hashtable = java.util.Hashtable;
var EncodeHintType = Packages.com.google.zxing.EncodeHintType;
var ErrorCorrectionLevel = Packages.com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
var QRCodeWriter = Packages.com.google.zxing.qrcode.QRCodeWriter;
var MatrixToImageWriter = Packages.com.google.zxing.client.j2se.MatrixToImageWriter;
var ImageIO = Packages.javax.imageio.ImageIO;
// QRコードの生成の設定
var format = BarcodeFormat.QR_CODE;
var width = 320;
var height = 320;
var hints = new Hashtable();
hints.put(
  EncodeHintType.ERROR_CORRECTION,
  ErrorCorrectionLevel.M);
// テキスト（URLの一覧）を読み込む
var html = "";
var text = readFile(FILE_LIST_TXT, "UTF-8");
var list = text.split("\r\n");
for (var i = 0; i < list.length; i++) {
  var url = list[i];
  if (url == "") continue;
  var fname = url.replace(/[^a-zA-Z0-9\-\_]/g,"_") + ".png";
  print("- " + url);
  html += "<img src='" + fname + "'>" + url + "<hr>";
  makeQRCode(fname, url);
}
// HTMLを保存
saveText("index.html", "<html><body>" + html + "</body></html>", "utf-8");
print("ok");
// QRコードを出力する
function makeQRCode(fname, contents) {
  var writer = new QRCodeWriter();
  var bm = writer.encode(contents, format, width, height, hints);
  var image = MatrixToImageWriter.toBufferedImage(bm);
  ImageIO.write(image, "png", new java.io.File(fname));
}

// テキストを保存する
function saveText(fname, text, encoding) {
  var osw = new java.io.OutputStreamWriter(
    new java.io.FileOutputStream(fname),
    encoding);
  osw.write(text, 0, text.length);
  osw.close();
}




#!/usr/bin/java -Dfile.encoding=UTF-8 -cp ./js.jar:core-3.2.0.jar:zxing-1.7-javase.jar org.mozilla.javascript.tools.shell.Main

load("makeqr.js");



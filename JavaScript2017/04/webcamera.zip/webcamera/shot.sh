#!/usr/bin/java -Dfile.encoding=UTF-8 -cp ./jar/js.jar:./jar/webcam-capture-0.3.10.jar:./jar/slf4j-api-1.7.2.jar:./jar/slf4j-nop-1.7.10.jar:./jar/bridj-0.6.2.jar org.mozilla.javascript.tools.shell.Main

load("shot.js");



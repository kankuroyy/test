// Webカメラを利用した定期的な連続撮影
var WAIT_TIME = 5000; // 撮影間隔(msec)

// ライブラリの宣言
var Webcam = Packages.com.github.sarxos.webcam.Webcam;
var ImageIO = javax.imageio.ImageIO;

// 撮影する
var webcam = Webcam.getDefault();
webcam.setViewSize(new java.awt.Dimension(640,480));
webcam.open();
// 定期的にキャプチャする
for (;;) {
  var image = webcam.getImage();
  var t = new Date();
  var fname = t.getFullYear() + "-" + (1+t.getMonth()) + "-" +
    t.getDate() + "_" + t.getHours() + "-" + t.getMinutes() +
    "-" + t.getSeconds() + ".jpeg";
  print("shot: " + fname);
  ImageIO.write(image, "JPEG", new java.io.File(fname));
  java.lang.Thread.sleep(WAIT_TIME); // 休む
}


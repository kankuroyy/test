// ocr.js for Rhino/JavaScript

// tesseract のパスを指定
var PATH_TESSERACT = "tesseract";
// 白黒の閾値
var THRESHOLD = 100;
var TMPFILE = "tmp.png";

// 入力されたファイルを一つずつ処理する
for (var i = 0; i < arguments.length; i++) {
  goOCR(arguments[i]);
}

// OCR処理を行う
function goOCR(infile) {
  // JavaのAPI
  var ImageIO = javax.imageio.ImageIO;
  // 入力ファイルを読み込む
  var image = ImageIO.read(new java.io.File(infile));
  // 白黒にする
  filterPixel(image, function(p) {
    // 二値化
    var avg = Math.ceil(p[0] + p[1] + p[2]) / 3;
    avg = (avg > THRESHOLD) ? 255 : 0;
    p[0] = p[1] = p[2] = avg;
  });
  ImageIO.write(image, "png", new java.io.File(TMPFILE));
  // tesseractを実行
  var cmd = [
    PATH_TESSERACT,
    TMPFILE,
    infile + "-ocr",
    "-l jpn",
    "whitelist.txt"
  ];
  runCommand.apply(this, cmd);
  var ocrfile = infile + "-ocr.txt";
  var result = readFile(ocrfile, "UTF-8");
  print("--- " + infile);
  // print(result);
  // 意味のありそうな部分をピックアップする
  result = result.split(" ").join("");
  // PRICE
  var prices = result.match(/\¥\d[0-9\,]+/g);
  for (var i in prices) {
    print("* PRICE=" + prices[i]);
  }
  // TEL
  var tels = result.match(/(TEL|tel)\:*[0-9\-]+/g);
  for (var i in tels) {
    print("* " + tels[i]);
  }
}

// 画像にフィルターをかける
function filterPixel(image, callback) {
  var raster = image.getRaster();
  var height = raster.getHeight();
  var width = raster.getWidth();
  var pixels = java.lang.reflect.Array.newInstance(
    java.lang.Integer.TYPE,
    raster.getNumDataElements());
  for (var y = 0; y < height; y++) {
    for (var x = 0; x < width; x++) {
      raster.getPixel(x, y, pixels);
      callback(pixels);
      raster.setPixel(x, y, pixels);
    }
  }
}

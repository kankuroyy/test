#!/usr/bin/java -Dfile.encoding=UTF-8 -cp ./jar/js.jar org.mozilla.javascript.tools.shell.Main

load("ocr.js");

// ワインの成分から等級を学習
var svm = require('node-svm');
var clf = new svm.CSVC();

// データを読み込む
const fs = require('fs');
let data = JSON.parse(fs.readFileSync('wine.json'));
data = shuffle(data);// データをシャッフルする
// 訓練データとテストデータを分ける
const test_n = Math.floor(data.length * 0.7);
const train_a = data.slice(0, test_n);
const test_a = data.slice(test_n);

// データを学習する
clf.train(train_a)
   .done(myTest);

// データをテストする
function myTest() {
  // 一件ずつテストする
  let ok = 0, count = 0;
  for (var i = 0; i < test_a.length; i++) {
    in_a = test_a[i][0];
    out_v = test_a[i][1];
    predict = clf.predictSync(in_a);
    if (out_v == predict) ok++;
    count++;
  }
  console.log("正解率=", ok / count, "=", ok, "/", count);
}

// データをシャッフルする
function shuffle(array) {
  var n = array.length, t, i;
  while (n) {
    i = Math.floor(Math.random() * n--);
    t = array[n];
    array[n] = array[i];
    array[i] = t;
  }
  return array;
}



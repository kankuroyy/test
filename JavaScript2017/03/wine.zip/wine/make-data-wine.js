// ワインデータを読み込み正規化を行う
const WINE_FILE = "wine.csv";
const JSON_FILE = "wine.json";
const fs = require('fs');

// ファイルを読み込む
let csv = readCSV(WINE_FILE);
// データを正規化(標準正規分布を計算)
// 最小値・最大値を調べる
const maxv = [];
const minv = [];
for (var i = 0; i <= 13; i++) {
  maxv.push(Number.MIN_VALUE);
  minv.push(Number.MAX_VALUE);
}
for (var i = 0; i < csv.length; i++) {
  let row = csv[i];
  for (var c = 1; c <= 13; c++) {
    let v = row[c];
    if (maxv[c] < v) { maxv[c] = v; }
    if (minv[c] > v) { minv[c] = v; }
  }
}
// 各値を0-1の範囲にする
for (let i = 0; i < csv.length; i++) {
  let row = csv[i];
  for (var c = 1; c <= 13; c++) {
    let range = maxv[c] - minv[c];
    row[c] = (row[c] - minv[c]) / range;
    if (0 <= row[c] && row[c] <= 1) {
    } else {
      console.log("[ERROR]", c, i, row[c], row);
    }
  }
}
const pat = [];
for (var i = 0; i < 3; i++) {
    pat[i] = [0,0,0];
    pat[i][i] = 1;
}
// JSONに変換
const data = [];
for (var i = 0; i < csv.length; i++) {
  let row = csv[i];
  let cl = parseInt(row[0]) - 1;
  let a = {
    "input": row.slice(1), 
    "output": pat[cl]
  };
  console.log(a);
  data.push(a);
}
fs.writeFileSync(JSON_FILE, JSON.stringify(data), "utf8");
console.log("ok");

// CSVファイルを読み込む関数
function readCSV(filename, delimiter) {
  if (delimiter == undefined) delimiter = ',';
  text = fs.readFileSync(filename, "utf8"); // CSVファイルを読む
  const lines = text.split("\n"); // 一行ずつに区切る
  lines.shift(); // 先頭のヘッダを削除
  const result = [];
  for (var i = 0; i < lines.length; i++) {
    let cells = lines[i].split(delimiter); // 区切り記号で区切る
    if (cells.length <= 1) continue;
    cells = cells.map(parseFloat); // 実数変換
    result.push(cells);
  }
  return result;
}


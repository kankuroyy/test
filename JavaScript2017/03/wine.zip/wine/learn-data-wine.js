// synaptic.jsの取り込み
const synaptic = require('synaptic');
const Layer = synaptic.Layer;
const Network = synaptic.Network;
const Trainer = synaptic.Trainer;
// 各レイヤーを生成
const inputLayer = new Layer(13);
const hiddenLayer = new Layer(110);
const outputLayer = new Layer(3);
// レイヤーを接続しニューラルネットワークを構築
inputLayer.project(hiddenLayer);
hiddenLayer.project(outputLayer);
const wine_network = new Network({
  input: inputLayer,
  hidden: [hiddenLayer],
  output: outputLayer
});

// データを読み込む
const fs = require('fs');
let data = JSON.parse(fs.readFileSync('wine.json'));
data = shuffle(data);// データをシャッフルする
// 訓練データとテストデータを分ける
const test_n = Math.floor(data.length * 0.7);
const train_a = data.slice(0, test_n);
const test_a = data.slice(test_n);

// データを学習する
const trainer = new Trainer(wine_network);
trainer.train(train_a, {
  rate: 0.2, iterations: 50, error: 0.1, 
  cost: Trainer.cost.CROSS_ENTROPY
});

// データのテスト
let ok = 0, count = 0;
for (var i = 0; i < test_a.length; i++) {
  in_a = test_a[i].input;
  out_v = argmax(test_a[i].output);
  predict = argmax(wine_network.activate(in_a));
  if (out_v == predict) ok++;
  count++;
}
console.log("正解率=", ok / count, ok, "/", count);

// データをシャッフルする
function shuffle(array) {
  var n = array.length, t, i;
  while (n) {
    i = Math.floor(Math.random() * n--);
    t = array[n];
    array[n] = array[i];
    array[i] = t;
  }
  return array;
}

// 配列nのうち最も大きな要素番号を返す
function argmax(n) {
  let v = Number.MIN_VALUE;
  let index = -1;
  for (let i = 0; i < n.length; i++) {
    if (v < n[i]) { index = i; v = n[i]; } 
  }
  return index;
}



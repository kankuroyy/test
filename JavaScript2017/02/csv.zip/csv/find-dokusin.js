var CSVObject = require('csv-lite').CSVObject;
var csv = new CSVObject();
csv.readFileSync('meibo.csv', 'sjis');

// 世帯人数が3人のデータを抽出
var res = csv.findAll(6, "独身");
// データを表示
console.log(res.length + "人いました");
for (var i in res) {
  var row = res[i];
  console.log(row[0], row[1], row[6]);
}


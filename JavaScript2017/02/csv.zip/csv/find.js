var CSVObject = require('csv-lite').CSVObject;
var csv = new CSVObject();
// サンプルの読込
csv.readFileSync('meibo.csv', 'sjis');

// 0列名(id)から1012を検索
var row = csv.find(0, 1012);
if (row < 0) {
  console.log('見つかりませんでした');
} else {
  console.log('見つかりました');
  var id = csv.getCell(row, 0);
  var name = csv.getCell(row, 1);
  console.log(id, name);
}

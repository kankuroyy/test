var CSVObject = require('csv-lite').CSVObject;
var csv = new CSVObject();
csv.readFileSync('meibo.csv', 'sjis');

// 世帯人数(多い順)で並び替え
csv.useHeader = true;
csv.sortNumber(5, false);
// 上位5人を表示
for (var i = 0; i <= 5; i++) {
  var name = csv.getCell(i, 1);
  var num  = csv.getCell(i, 5);
  console.log(name + "(" + num + ")");
}


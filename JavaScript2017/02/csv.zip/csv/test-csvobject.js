// モジュールを取り込む
var CSVObject = require('csv-lite').CSVObject;
var csv = new CSVObject();

// ファイルを読み込む
csv.readFileSync('meibo.csv', 'sjis');

// 内容を表示
var id    = csv.getCell(1, 0);
var name  = csv.getCell(1, 1);
var email = csv.getCell(1, 2);
console.log("(" + id + ") " + name + "<" + email + ">");


var CSV = require('csv-lite');

// Shift_JISのファイルを読み込む
var meibo = CSV.readFileSync('meibo.csv', 'sjis');

// Shift_JISでCSVファイルを書き込む
CSV.writeFile('meibo2.csv', meibo, 'sjis');



var CSVObject = require('csv-lite').CSVObject;
var csv = new CSVObject();
csv.readFileSync('meibo.csv', 'sjis');

console.log("データ数=" + csv.length);

// --- 追加 ---
// データを末尾に追加
csv.add(
  [1060, "山下 次郎", "yj@example.com","","", 3, "既婚"]);
// 途中に追加
csv.insertRow(1,
  [999, "伊藤 三郎", "si@example.com", "","", 1, "独身"]);
// 結果を表示
console.log("2件追加：データ数=" + csv.length);

// --- 削除 ---
var row = csv.find(0, 1015);
if (row >= 0) csv.deleteRow(row);
// 結果を表示
console.log("1件削除：データ数=" + csv.length);



#!/bin/sh
cd `dirname $0`
node png-pack.js "$@"



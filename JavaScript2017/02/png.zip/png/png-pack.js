var pngm = require('./png-metadata');
var fs = require('fs');
var path = require('path');
var crypto = require('crypto');

// マスターパスワード
var PASSWORD = "vScOPdxBTQ3X9jNQ";
var APP_CHUNK = "pcOj"; // 四文字で三文字目を大文字にする
// メイン
checkArg();

function checkArg() {
  var argv = process.argv;
  if (argv.length <= 2) {
    console.log('no input'); return;
  }
  if (argv.length == 3) {
    unpack(argv[2]); return;
  }
  if (argv.length == 4) {
    pack(argv[2],argv[3]); return;
  }
  console.log("Too many files.");
}

function unpack(f) {
  var tmp = pngm.readFileSync(f);
  if (!pngm.isPNG(tmp)) {
    console.log("no png file"); return;
  }
  var list = pngm.splitChunk(tmp);
  var body = '';
  for (var i in list) {
    var chunk = list[i];
    if (chunk.type == APP_CHUNK) {
      body = chunk.data; break;
    }
  }
  if (body != '') {
    var o = JSON.parse(body);
    var name = o["name"];
    var data = aes256_decode(o["data"]);
    var dir = path.dirname(f);
    fs.writeFileSync(dir + '/' + "out-" + name, data);
  }
  console.log("ok, export=out-" + name);
}

function pack(f1, f2) {
  var pngfile = '', datafile = '';
  if (f1.match(/\.png$/)) {
    pngfile = f1, datafile = f2;
  } else {
    pngfile = f2, datafile = f1;
  }
  var outfile = pngfile.replace(/\.png$/, '-out.png');
  // ファイルを暗号化
  var enc = aes256_encode_file(datafile);
  var json = JSON.stringify({
    'name': path.basename(datafile),
    'data': enc
  });
  // 元ファイルを読み込み
  var tmp = pngm.readFileSync(pngfile);
  var list = pngm.splitChunk(tmp);
  list.pop(); // IENDを削除
  // 新しく適当なチャンクを作成
  var newchunk = pngm.createChunk(APP_CHUNK, json);
  list.push(newchunk);
  list.push(pngm.createChunk('IEND', ''));
  var newpng = pngm.joinChunk(list);
  fs.writeFileSync(outfile, newpng, 'binary');
  console.log('ok! output=' + outfile);
}


function aes256_encode_file(path) {
  var bin = fs.readFileSync(path);
  var cipher = crypto.createCipher('aes-256-cbc', PASSWORD);
  var res = cipher.update(bin, 'binary', 'hex');
  res += cipher.final("hex");
  return res;
}

function aes256_decode(data) {
  var decipher = crypto.createDecipher('aes-256-cbc', PASSWORD);
  var res = Buffer.concat([
    decipher.update(data, 'hex'),
    decipher.final()]);
  return res;
}





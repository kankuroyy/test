// ライブラリの取り込み
var piexif = require('piexifjs');
var fs = require('fs');
var path = require('path');
var crypto = require('crypto');

// マスターパスワード
var password = "vScOPdxBTQ3X9jNQ";

// メイン
checkArgv();

function checkArgv() {
  // 引数を確認
  var argv = process.argv;
  if (argv.length <= 2) {
    console.log('No input');
    return;
  }

  // ファイル1つ = JPEGファイルの取り出し
  if (argv.length == 3) {
    unpack(argv[2]);
    return;
  }

  // ファイル２つ JPEGファイルへの埋め込み
  if (argv.length == 4) {
    var re_jpeg = /\.(jpg|jpeg)$/;
    var arg = [argv[2], argv[3]];
    var jpeg, data;
    for (var i in arg) {
      var f = arg[i];
      if (re_jpeg.test(f)) {
        jpeg = f;
      } else {
        data = f;
      }
    }
    if (jpeg == undefined || data == undefined) {
      console.log('no jpeg file'); return;
    }
    pack(jpeg, data);
    return;
  }
  console.log('too many files');
}

// 画像からファイルを分離する
function unpack(jpeg_file) {
  var json = jpeg_extract(jpeg_file);
  var o = JSON.parse(json);
  var name = path.dirname(jpeg_file) + "/out-" + o["name"];
  var bin = aes256_decode(o["data"]);
  fs.writeFileSync(name, bin);
  console.log("ok: " + name);
}

// 画像にファイルを埋め込む
function pack(jpeg_file, data_file) {
  var hex = aes256_encode_file(data_file);
  var o = { 'name': path.basename(data_file),
            'data': hex };
  var outfile = jpeg_file.replace(/\.(jpg|jpeg)$/, "-out.jpeg");
  jpeg_insert(jpeg_file, outfile, JSON.stringify(o));
  console.log("packed : " + outfile);
}


function aes256_encode_file(path) {
  var bin = fs.readFileSync(path);
  var cipher = crypto.createCipher('aes-256-cbc', password);
  var res = cipher.update(bin, 'binary', 'hex');
  res += cipher.final("hex");
  return res;
}

function aes256_decode(data) {
  var decipher = crypto.createDecipher('aes-256-cbc', password);
  var res = Buffer.concat([
    decipher.update(data, 'hex'),
    decipher.final()]);
  return res;
}

function jpeg_insert(in_jpeg, out_jpeg, str) {
  // JPEGファイルを読む
  var jpeg = fs.readFileSync(in_jpeg);
  var jpeg_data = jpeg.toString("binary");
  
  // 既存のExifデータを読む
  var exif_obj = piexif.load(jpeg_data);
  
  // UserCommentを置き換え
  if (!exif_obj["Exif"]) exif_obj["ExifIFD"] = {};
  exif_obj["Exif"][piexif.ExifIFD.UserComment] = str;

  // Exifバイナリを作成
  var exif_bytes = piexif.dump(exif_obj);
  if (exif_bytes.length> 0xffff) {
    throw new Error('Sorry, data size too big. size=' + exif_bytes.length);
  }
  // JPEGファイルに挿入
  var bin = piexif.insert(exif_bytes, jpeg_data);
  // ファイルに保存
  fs.writeFileSync(out_jpeg, new Buffer(bin, "binary"));
}



function jpeg_extract(jpegfile) {
  // JPEGファイルを読む
  var jpeg = fs.readFileSync(jpegfile);
  var jpeg_data = jpeg.toString("binary");
  
  // 既存のExifデータを読む
  var exif_obj = piexif.load(jpeg_data);
   
  // UserCommentを取り出す
  if (!exif_obj["Exif"]) exif_obj["Exif"] = {};
  var data = exif_obj["Exif"][piexif.ExifIFD.UserComment];
  return data; 
}






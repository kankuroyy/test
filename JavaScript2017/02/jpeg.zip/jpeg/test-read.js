// モジュールの取り込み
var piexif = require('piexifjs');
var fs = require('fs');

// JPEGファイルを読む
var jpeg = fs.readFileSync("test.jpg");
var jpeg_data = jpeg.toString("binary");

// 既存のExifデータを読む
var exif_obj = piexif.load(jpeg_data);
console.log(exif_obj);


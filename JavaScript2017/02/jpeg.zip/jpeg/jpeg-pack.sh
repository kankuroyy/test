#!/bin/sh
cd `dirname $0`
node jpeg-pack.js "$@"



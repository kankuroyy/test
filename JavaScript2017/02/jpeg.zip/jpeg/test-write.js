// モジュールの取り込み
var piexif = require('piexifjs');
var fs = require('fs');

// JPEGファイルを読む --- (*1)
var jpeg = fs.readFileSync("test.jpg");
var jpeg_data = jpeg.toString("binary");

// Exifデータを用意する --- (*2)
var zeroth = {}, exif = {}, gps = {};
zeroth[piexif.ImageIFD.Make] = "Make";
zeroth[piexif.ImageIFD.Software] = "test";
exif[piexif.ExifIFD.DateTimeOriginal] = "2016:03:01 12:34:56";
var exif_obj = {"0th":zeroth,"Exif":exif,"GPS":gps};

// Exifデータを生成し、JPEGに埋め込む --- (*3)
var exif_bytes = piexif.dump(exif_obj);
var newjpeg_bytes = piexif.insert(exif_bytes, jpeg_data);

// ファイルに出力する --- (*4)
fs.writeFileSync("output.jpg", new Buffer(newjpeg_bytes, "binary"));


var num = 835;
do {
  // 下一桁を取り出す
  var n = num % 10;
  console.log(n);
  // 10で割る
  num = Math.floor(num / 10);
} while (num > 0); // 必要なら続ける


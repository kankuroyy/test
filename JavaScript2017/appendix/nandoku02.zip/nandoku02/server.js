// 設定
var HTTP_PORT = 8080;

// 必要なモジュールの読み込み
var http = require('http'),
  url = require('url'),
  path = require('path'),
  fs = require('fs');

// サーバー処理
http.createServer(function (req, res) {
  // どのファイルにアクセスするのか調べる
  if (req.url == "/") req.url = "/make-script-image.html";
  var x = url.parse(req.url, true);
  var fullpath = path.resolve(__dirname, "." + x.pathname);
  // アクセスするファイルが存在する？
  if (fs.existsSync(fullpath)) {
    // 送信しても良いファイルか調べる
    var ext = path.extname(fullpath).toLowerCase();
    if (ext.match(/\.(png|jpg|jpeg|gif|html|css)$/)) {
      var strm = fs.createReadStream(fullpath);
      strm.pipe(res);
      return;
    }
  }
  // 予想外のリクエストにはエラーを返す
  res.writeHead(404, {'Content-Type':'text/plain'});
  res.end("404 not found");
})
.listen(HTTP_PORT);
console.log("start server");
console.log("http://localhost:" + HTTP_PORT);


// ES2015で書いた掲示板アプリ
const http = require('http');
const url = require('url');
const fs = require('fs');
const port = 8080;
const html_header = { 'Content-Type': 'text/html' };
const log_path = __dirname + "/bbs.log";
const template_path = __dirname + "/template.html";

class BBS_Server {
  start() {
    http.createServer((req, res)=>{
      this.request(req, res);
    }).listen(port);
    console.log("Server started.");
  }
  request(req, res) {
    console.log(this);
    const q = url.parse(req.url, true);
    const path = q.pathname;
    console.log("path=" + path);
    switch (path) {
      case "/":
        this.showLog(q, res);
        break;
      case "/write":
        this.writeLog(q, res);
        break;
      default:
        res.writeHead(404, html_header);
        break;
    }
  }
  showLog(q, res) {
    const html = fs.readFileSync(template_path, "utf-8");
    const log_a = this.loadLog();
    console.log("log_a="+JSON.stringify(log_a));
    const log_h = log_a.map(n => {
      const name = toHtml(n[0]);
      const body = toHtml(n[1]);
      return `<p class="talk">${name} &gt; ${body}</p>`; 
    }).join("\n");
    const html_log = html.replace("[[LOG]]", log_h);
    res.writeHead(200, html_header);
    res.write(html_log);
    res.end();
  }
  writeLog(q, res) {
    const f = q.query;
    const log_a = this.loadLog();
    log_a.unshift([f.name, f.body]);
    const log_s = JSON.stringify(log_a);
    fs.writeFile(log_path, log_s, err => {
      if (err) {
        showError("ログファイルの生成に失敗", res);
        return;
      }
      // トップページにリダイレクト
      res.writeHead(302, {"location":"/"});
      res.end();
    });
  }
  loadLog() {
    try {
      const s = fs.readFileSync(log_path, "utf-8");
      return JSON.parse(s);
    } catch (e) {
      return [];
    }
  }
  showError(err, res) {
    res.writeHead(500, html_header);
    res.write("Error:" + err);
    res.end();
  }
}
// BBS_Serverのオブジェクトを生成
const server = new BBS_Server();
server.start();

function toHtml(s) {
  return s
    .replace("&", "&amp;")
    .replace(">", "&gt;")
    .replace("<", "&lt;");
}






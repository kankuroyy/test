class Hoge {
  // name = "Jiro"
  constructor() {
    this.name = "Jiro";
  }
  sayHello() { console.log("Hello, " + this.name); }
}
const hoge = new Hoge();
hoge.sayHello();

